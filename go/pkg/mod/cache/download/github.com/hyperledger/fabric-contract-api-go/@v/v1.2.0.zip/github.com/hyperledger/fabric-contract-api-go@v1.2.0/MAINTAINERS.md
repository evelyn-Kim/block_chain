Maintainers
===========

| Name                      | GitHub           | Chat           | email                               |
|---------------------------|------------------|----------------|-------------------------------------|
| James Taylor              | jt-nti           | jtonline       | jamest@uk.ibm.com                   |
| Matthew White             | mbwhite          |                | whitemat@uk.ibm.com                 |

Also: Please see the [Release Manager section](https://github.com/hyperledger/fabric/blob/main/MAINTAINERS.md)
