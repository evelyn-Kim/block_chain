package envy

const Version = "v1.10.1"
