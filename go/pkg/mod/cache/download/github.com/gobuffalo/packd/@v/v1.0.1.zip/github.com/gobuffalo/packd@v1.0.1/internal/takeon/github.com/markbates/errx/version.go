package errx

// Version of errx
const Version = "v1.0.0"
